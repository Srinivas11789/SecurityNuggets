My brother likes esoteric programming. He sent me this file but I don't see what it is for. Could you help me ?

[GFlag files](https://static.ctf.insecurity-insa.fr/a7572eb34ba9700b39f1ba7f5869bf301b67d406.tar.gz)
