# Note about cookie

The challenge bot has its cookie set on `https://political-web.chal.irisc.tf`.
